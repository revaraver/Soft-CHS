作者：revar
该汉化补丁对应madVR目前最新版本V0.92.17
内有【原文件】，【硬汉化】，【软汉化】三个文件夹
半完全汉化，保留了部分术语，汉化率高于90%
如果遇到汉化文本错误或不合理的地方，欢迎大家到我的Github主页（下方作者信息处）
进行反馈，在那里可以找到我的邮箱


有两种汉化操作方法：

方法一：
将【软汉化】文件夹中的全部文件拷贝至madVR的安装目录下

推荐该方法，没有修改原文件


若方法一没有实现汉化，则使用方法二
方法二：
1.删除madVR目录下对应的三个后缀为【CH】的文件（若有的话）
2.将【硬汉化】文件夹中的全部文件拷贝至madVR的安装目录下覆盖即可（可自行备份）


恢复英文：
1.删除madVR目录下对应【软汉化】中的三个后缀为【CH】的文件（若有的话）
2.将【原文件】文件夹中的全部文件拷贝至madVR的安装目录下覆盖即可




相关信息
--------------------------------------------------------------------------------------------
作者：
revar

存储于Github：
https://github.com/revaraver/Soft-CHS

首次发布于VCB-S论坛：


个人主页：
https://github.com/revaraver


附录：文件列表
--------------------------------------------------------------------------------------------
文件名称：*\madVR.CHS for V.92.17\硬汉化\madHcCtrl.exe
文件大小：3129320 字节
修改时间：2018年11月27日 00:14:02
MD5     ：0FE4CD26336B9E1BD6413DBE603576D0
SHA1    ：E2B4A03E1B8C15DAE3FA30DDFB97A89908E46B9A
CRC32   ：0B54CD9E

文件名称：*\madVR.CHS for V.92.17\硬汉化\madLevelsTweaker.exe
文件大小：992616 字节
修改时间：2018年11月26日 23:53:08
MD5     ：CF558CF411EBECC0B198CC676235EBE5
SHA1    ：08D22DA2E4DA70F0537840FAC88BB2AE9FE84DEA
CRC32   ：BDC00862

文件名称：*\madVR.CHS for V.92.17\硬汉化\madTPG.exe
文件大小：1163488 字节
修改时间：2018年11月26日 23:51:46
MD5     ：5C93190F4721B8D968582D97A53989EA
SHA1    ：6281BE67046CC6253E72C69BEF8B8255AC6DBC36
CRC32   ：83037F38

文件名称：*\madVR.CHS for V.92.17\软汉化\madHcCtrl.CH
文件大小：579072 字节
修改时间：2018年11月27日 00:14:02
MD5     ：07A264C2FCCBD43B0A03438678127DF1
SHA1    ：BADBA42EBAFDFC6B38F5D28AF891B10FF258C3C0
CRC32   ：2BF46914

文件名称：*\madVR.CHS for V.92.17\软汉化\madLevelsTweaker.CH
文件大小：126464 字节
修改时间：2018年11月26日 23:53:08
MD5     ：EDEDABEFE1DC15EBA36FEDFC3C69615D
SHA1    ：C6680342826B783FBA67C339B4F13F1031876EF7
CRC32   ：00F66D95

文件名称：*\madVR.CHS for V.92.17\软汉化\madTPG.CH
文件大小：76288 字节
修改时间：2018年11月26日 23:51:46
MD5     ：84DE5BEC4D0494649CD10EC6C7E507FF
SHA1    ：792D5EBC19C70781068BB3D38B8FA189306A0FE0
CRC32   ：DC0670C6

文件名称：*\madVR.CHS for V.92.17\原文件\madHcCtrl.exe
文件大小：3222504 字节
文件版本：1.1.21.0
修改时间：2018年9月29日 12:37:50
MD5     ：B841D408448F2A07F308CED1589E7673
SHA1    ：F5B5095C0ED69D42110DF6D39810D12B1FA32A1E
CRC32   ：BF8E6360

文件名称：*\madVR.CHS for V.92.17\原文件\madLevelsTweaker.exe
文件大小：993640 字节
文件版本：1.1.1.0
修改时间：2014年4月1日 16:23:54
MD5     ：03B55F67E6C16B4CE993401DE8AC3E1F
SHA1    ：4912D5F5466852A86FB416A4DC553D3B0FAAE772
CRC32   ：09635066

文件名称：*\madVR.CHS for V.92.17\原文件\madTPG.exe
文件大小：1219808 字节
文件版本：1.0.7.0
修改时间：2017年9月13日 17:27:40
MD5     ：E16AB3A14FFDB10A53BB01776E7D05D4
SHA1    ：ECDD97C51A6FE185B48149C170320BC2F8D38433
CRC32   ：4906A2BF



